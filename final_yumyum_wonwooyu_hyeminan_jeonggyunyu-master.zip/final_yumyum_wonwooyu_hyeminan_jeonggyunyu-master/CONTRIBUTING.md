# 협업 규칙 (Contributing Guide)

> 코드 관리의 일관성과 가독성을 위한 팀 협업 가이드입니다. 모든 팀원은 아래 규칙을 준수합니다.

---

## 1. 브랜치 전략

### 브랜치 구조
```
main        → 최종 배포 브랜치 (직접 push 금지)
develop     → 통합 개발 브랜치 (기능 브랜치의 머지 대상)
feat/...    → 기능 개발 브랜치
fix/...     → 버그 수정 브랜치
```

### 브랜치 명명 규칙
```
[Type]/[Name]/[Task]
```

| Type | 설명 |
|------|------|
| `feat` | 새로운 기능 구현 |
| `fix` | 버그 및 오류 수정 |
| `docs` | 문서 수정 |
| `refactor` | 코드 구조 개선 (기능 변경 없음) |
| `chore` | 패키지 관리, 빌드 설정 등 |

**예시**
```
feat/nyt/login-api
fix/js/payment-error
docs/kim/update-readme
```

---

## 2. 커밋 메시지 규칙

### 형식
```
[Type]: [Description]
```

### 규칙
- 설명은 **한글**로 명확하게 작성
- 마침표 생략
- 과거 시제 사용 금지 (수정했음 ❌ → 수정 ✅)

### 예시
```
feat: 상품 검색 필터 기능 추가
fix: 결제 페이지 레이아웃 깨짐 수정
docs: README 설치 가이드 업데이트
refactor: 데이터베이스 연결 로직 클래스화
chore: 패키지 의존성 추가 (requests)
```

---

## 3. 작업 워크플로우

```bash
# 1. develop 최신화
git checkout develop
git pull origin develop

# 2. 브랜치 생성
git checkout -b feat/이름/작업내용

# 3. 작업 및 커밋
git add .
git commit -m "feat: 기능 설명"

# 4. 푸시
git push origin feat/이름/작업내용

# 5. GitLab에서 develop으로 MR 생성
```

---

## 4. MR(Merge Request) 규칙

- MR 대상 브랜치는 항상 **develop**
- **1명 이상 Approve** 후 머지
- MR 템플릿 양식 필수 작성
- 머지된 브랜치는 즉시 삭제
- 본인 MR은 본인이 직접 머지 (Approve 받은 후)

### 리뷰어 가이드
- 24시간 이내 리뷰 권장
- 단순 의견은 `[nit]` 접두어 사용 (필수 반영 아님)
- 수정 요청 시 구체적인 이유 작성

---

## 5. develop → main 머지 기준

- 기능 구현 완료 및 테스트 통과 시
- 전원 합의 후 머지

---

## 6. 충돌 해결 규칙

- **merge** 방식 사용 (rebase 금지)
- 충돌 발생 시 관련 팀원과 함께 해결
- 혼자 임의로 상대방 코드 수정 금지
